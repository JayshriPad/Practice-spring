package com.msedcl.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.msedcl.main.domain.Language;

import com.msedcl.main.repository.LanguageRepository;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Service
@Slf4j
public class LanguageServiceImpl implements LanguageService {

	private final LanguageRepository languageRepository;


	@Override
	public Language updateLanguage(Language language) {
		return  languageRepository.updateLanguage(language);
		
	}

	/*@Override
	public Employee updateEmployee(Employee employee) {
		return employeeRepository.updateEmployee(employee);
	}


	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.getAllEmployees();
	}
*/

}

