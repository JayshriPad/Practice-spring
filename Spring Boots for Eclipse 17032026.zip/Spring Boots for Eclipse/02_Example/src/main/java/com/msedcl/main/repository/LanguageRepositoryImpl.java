package com.msedcl.main.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;


import com.msedcl.main.domain.Language;

import lombok.extern.slf4j.Slf4j;
//private List<Language> languageList = new ArrayList<>();


@Repository
@Slf4j
public class LanguageRepositoryImpl implements LanguageRepository {
	

@Override
public Language updateLanguage(Language language) {
	Language l =new Language();
		if (language!=null) {
			
			l.setReplaceWith(language.getReplaceBy());
			l.setReplaceBy(language.getReplaceWith());
			l.setTextOne(language.getTextOne());
			return l;
		}
	
	return null;
}

	
	/*private List<Employee> employeeList = new ArrayList<>();

	public boolean addNewEmployee(Employee employee) {
		return employeeList.add(employee);
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		Employee employee = getEmployeeByEmployeeId(employeeId);
		if (employee != null)
			return employeeList.remove(employee);
		return false;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		for (Employee e : employeeList) {
			if (e.getEmployeeId() == employee.getEmployeeId()) {
				e.setFirstName(employee.getFirstName());
				e.setLastName(employee.getLastName());
				e.setSalary(employee.getSalary());
				return e;
			}
		}
		return null;
	}

	@Override
	public Employee getEmployeeByEmployeeId(int employeeId) {
		for (Employee employee : employeeList) {
			if (employee.getEmployeeId() == employeeId)
				return employee;
		}
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeList;
	}
*/
}