
package com.msedcl.main.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.domain.Language;
//import com.msedcl.main.domain.Employee;
import com.msedcl.main.dto.ResponseDTO;
//import com.msedcl.main.service.EmployeeService;
import com.msedcl.main.service.LanguageService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("languageapi")
@AllArgsConstructor
public class LanguageController {
	
	private final LanguageService languageService;
	// http://localhost:8181/employeecrudapi/employees/employee
			@PutMapping("language")
			public ResponseEntity<ResponseDTO> updateLanguage(@RequestBody Language language) {
				log.info(language.toString());
				Language updatedLanguage = languageService.updateLanguage(language);
				if (updatedLanguage!=null) {
					ResponseDTO responseDTO = new ResponseDTO(HttpStatus.OK, "Spring is best");
					return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
				} else {
					ResponseDTO responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Invalid operation");
					return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(responseDTO);
				}

			}
		
	
/*	private final EmployeeService employeeService;

	//http://localhost:8181/employeecrudapi/employees/employee/101
	@DeleteMapping("employees/employee/{employeeId}")
	public ResponseEntity<ResponseDTO> removeEmployee(@PathVariable int employeeId) {
		if (employeeService.deleteEmployeeByEmployeeId(employeeId)) {
			ResponseDTO responseDTO = new ResponseDTO(HttpStatus.OK, "Employee Deleted Successfully");
			return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
		} else {
			ResponseDTO responseDTO = new ResponseDTO(HttpStatus.OK, "Employee Delete Successfully");
			return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
		}
	}
	
	// http://localhost:8181/employeecrudapi/employees/employee
		@PutMapping("employees/employee")
		public ResponseEntity<ResponseDTO> updateEmployee(@RequestBody Employee employee) {
			log.info(employee.toString());
			Employee updatedEmployee = employeeService.updateEmployee(employee);
			if (updatedEmployee!=null) {
				ResponseDTO responseDTO = new ResponseDTO(HttpStatus.OK, "Employee Updated Successfully");
				return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
			} else {
				ResponseDTO responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Failed to Update Employee");
				return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(responseDTO);
			}

		}
	
	
	// http://localhost:8181/employeecrudapi/employees/employee
	@PostMapping("employees/employee")
	public ResponseEntity<ResponseDTO> newEmployee(@RequestBody Employee employee) {
		log.info(employee.toString());
		boolean insertStatus = employeeService.addNewEmployee(employee);
		if (insertStatus) {
			ResponseDTO responseDTO = new ResponseDTO(HttpStatus.OK, "New Employee Added Successfully");
			return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
		} else {
			ResponseDTO responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Failed to add Employee");
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(responseDTO);
		}

	}
	//http://localhost:8181/employeecrudapi/employees
	@GetMapping("employees")
	public ResponseEntity<List<Employee>> allEmployees() { // Method Returning Response
		
		
		return ResponseEntity.status(HttpStatus.OK).body(employeeService.getAllEmployees());
					
		}
		
		//http://localhost:8181/employeecrudapi/employees/employee/101
	@GetMapping("employees/employee/{employeeId}")
	public ResponseEntity<Employee> singleEmployee(@PathVariable int employeeId) { // Method Returning Response
		
		
		return ResponseEntity.status(HttpStatus.OK).body(employeeService.getEmployeeByEmployeeId(employeeId));
					
		}
	*/	
	
}
