package com.msedcl.main.repository;

import java.util.List;

import com.msedcl.main.domain.Language;

public interface LanguageRepository {
	Language updateLanguage(Language language);
	/*boolean addNewEmployee(Employee employee);
	boolean deleteEmployeeByEmployeeId(int employeeId);
	Employee updateEmployee(Employee employee);
	Employee getEmployeeByEmployeeId(int employeeId);
	List<Employee> getAllEmployees();*/
}