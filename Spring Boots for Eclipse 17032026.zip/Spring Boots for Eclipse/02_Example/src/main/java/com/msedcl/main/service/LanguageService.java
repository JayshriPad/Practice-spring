package com.msedcl.main.service;

import java.util.List;


import com.msedcl.main.domain.Language;

public interface LanguageService {


	//public List<Language> getAllEmployees() {

	

	Language updateLanguage(Language language);

	
}
