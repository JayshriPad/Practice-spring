package com.msedcl.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msedcl.main.domain.Employee;
import com.msedcl.main.dto.EmployeeDTO;
import com.msedcl.main.exception.EmployeeNotFoundException;
import com.msedcl.main.mapper.EmployeeMapper;
import com.msedcl.main.repository.EmployeeRepository;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;

	@Override
	public EmployeeDTO addNewEmployee(EmployeeDTO employeeDTO) {
		
		Employee employee= EmployeeMapper.mapTpEmployee(employeeDTO, new Employee());
		
		Employee insertedEmployee= employeeRepository.save(employee);
		
		Optional<Employee> optionalEmployee = employeeRepository.findById(insertedEmployee.getEmployeeId());
		if (optionalEmployee.isPresent()) {
			Employee existingEmployee = optionalEmployee.get();
			EmployeeDTO addedEmployeeDTO = EmployeeMapper.mapTpEmployeeDTO(existingEmployee, new EmployeeDTO());
			return addedEmployeeDTO;
		} else
			return null;
		
		
		
	}
	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		// Employee existingEmployee = employeeRepository.getById(employeeId);
		Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
		if (optionalEmployee.isPresent()) {
			Employee employee = optionalEmployee.get();
			employeeRepository.delete(employee);
			return true;
		} else 
			throw new EmployeeNotFoundException("Invalid Email Id :: " + employeeId);
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO) {
		Employee employee = EmployeeMapper.mapTpEmployee(employeeDTO, new Employee());
		Optional<Employee> optionalEmployee = employeeRepository.findById(employee.getEmployeeId());
		if (optionalEmployee.isPresent()) {
			Employee updatedEmployee = employeeRepository.save(employee);
			EmployeeDTO updateEmployeeDTO = EmployeeMapper.mapTpEmployeeDTO(updatedEmployee, new EmployeeDTO());
			return updateEmployeeDTO;
		} else
			return null;
	}

	@Override
	public EmployeeDTO getEmployeeByEmployeeId(int employeeId) {
		Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
		if (optionalEmployee.isPresent()) {
			Employee existingEmployee = optionalEmployee.get();
			EmployeeDTO employeeDTO = EmployeeMapper.mapTpEmployeeDTO(existingEmployee, new EmployeeDTO());
			return employeeDTO;
		} else
			 throw new EmployeeNotFoundException("Invalid Email Id :: " + employeeId);
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		List<EmployeeDTO> employeeDTOList = new ArrayList<>();

		for (Employee employee : employeeRepository.findAll()) {
			EmployeeDTO employeeDTO = EmployeeMapper.mapTpEmployeeDTO(employee, new EmployeeDTO());
			employeeDTOList.add(employeeDTO);
		}

		return employeeDTOList;
	}
}
//	@Override
//	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		
		
		/*if(employee!=null)
		{ employeeRepository.delete(employee);
		return true;
		}
		return false;
		*/
	//	Optional<Employee> optonalEmployee=employeeRepository.findById(employeeId);// return type Optional<Employee> 
		
		
	//	if(optonalEmployee.isPresent()) {
	//		Employee employee=optonalEmployee.get();
	//		employeeRepository.delete(employee);
	//		return true;
	//	}else {
	//		return false;
	//	}
		
	//}

		
//}

// backup
//@Override
//	public EmployeeDTO updateEmployee(EmployeeDTO employeeDto) {
		/*Employee employee1=employeeRepository.getById(employee.getEmployeeId());
		
		if(employee!=null)
		{ 
		 return employeeRepository.save(employee); //save to update records
		}
		return null;*/
  // Optional<Employee> optonalEmployee=employeeRepository.findById(employeeDto.getEmployeeId());// return type Optional<Employee> 
		
		/*if(employee!=null)
		{ employeeRepository.delete(employee);
		return true;
		}
		return false;
		*/
		
	//	if(optonalEmployee.isPresent()) {
			
	//		Employee updateEmployee = EmployeeMapper.mapTpEmployeeDTO(optonalEmployee, new EmployeeDTO());
	//		return employeeRepository.save(updateEmployee);
	//	}else {
	//		return null;
	//	}
	//}

	//@Override
	//public Employee getEmployeeByEmployeeId(int employeeId) {
		//return employeeRepository.getById(employeeId);
		
		//  Optional<Employee> optonalEmployee=employeeRepository.findById(employeeId);// return type Optional<Employee> 
		//  if(optonalEmployee.isPresent()) {
				
		//		return optonalEmployee.get();
		//	}else {
		//		return null;
		//	}
	//}

	//@Override
	//public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
	//	return employeeRepository.findAll();
	//}

//-----------------------------------

/*
 package com.msedcl.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.msedcl.main.domain.Employee;
import com.msedcl.main.dto.EmployeeDTO;
import com.msedcl.main.mapper.EmployeeMapper;
import com.msedcl.main.repository.EmployeeRepository;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;

	@Override
	public boolean addNewEmployee(EmployeeDTO employeeDTO) {
		Employee employee = EmployeeMapper.mapToEmployee(employeeDTO, new Employee());
		Employee insertedEmployee = employeeRepository.save(employee);
		if (insertedEmployee != null)
			return true;
		return false;
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		// Employee existingEmployee = employeeRepository.getById(employeeId);
		Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
		if (optionalEmployee.isPresent()) {
			Employee employee = optionalEmployee.get();
			employeeRepository.delete(employee);
			return true;
		} else
			return false;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO) {
		Employee employee = EmployeeMapper.mapToEmployee(employeeDTO, new Employee());
		Optional<Employee> optionalEmployee = employeeRepository.findById(employee.getEmployeeId());
		if (optionalEmployee.isPresent()) {
			Employee updatedEmployee = employeeRepository.save(employee);
			EmployeeDTO updateEmployeeDTO = EmployeeMapper.mapTpEmployeeDTO(updatedEmployee, new EmployeeDTO());
			return updateEmployeeDTO;
		} else
			return null;
	}

	@Override
	public EmployeeDTO getEmployeeByEmployeeId(int employeeId) {
		Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
		if (optionalEmployee.isPresent()) {
			Employee existingEmployee = optionalEmployee.get();
			EmployeeDTO employeeDTO = EmployeeMapper.mapTpEmployeeDTO(existingEmployee, new EmployeeDTO());
			return employeeDTO;
		} else
			return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		List<EmployeeDTO> employeeDTOList = new ArrayList<>();

		for (Employee employee : employeeRepository.findAll()) {
			EmployeeDTO employeeDTO = EmployeeMapper.mapTpEmployeeDTO(employee, new EmployeeDTO());
			employeeDTOList.add(employeeDTO);
		}

		return employeeDTOList;
	}

} */
