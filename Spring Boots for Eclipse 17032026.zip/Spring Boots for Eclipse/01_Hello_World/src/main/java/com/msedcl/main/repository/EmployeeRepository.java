package com.msedcl.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.msedcl.main.domain.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	/*boolean addNewEmployee(Employee employee);
	boolean deleteEmployeeByEmployeeId(int employeeId);
	Employee updateEmployee(Employee employee);
	Employee getEmployeeByEmployeeId(int employeeId);
	List<Employee> getAllEmployees();*/
}