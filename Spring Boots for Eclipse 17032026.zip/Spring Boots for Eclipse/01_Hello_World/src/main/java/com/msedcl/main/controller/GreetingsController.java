package com.msedcl.main.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

//http://localhost:8181/myfirstapi/greet
@Slf4j
@RestController // handle REST API requests
@RequestMapping("myfirstapi") // search for URL
public class GreetingsController {

	// private static final Logger LOGGER=
	// LoggerFactory.getLogger(GreetingsController.class); //slf4j.Logger;//if used
	// lombok no need to write logger

	public GreetingsController() {
		log.info("GreetingsController object created!!");// LOGGER.info("GreetingsController object created!!");
	}

	// endpoint :: http://localhost:8181/myfirstapi/greetdelete
	@DeleteMapping("greetdelete")
	public ResponseEntity<String> deleteGreetings() {
		log.info("deleteGreetings()");

		return ResponseEntity.status(HttpStatus.OK).body("Testing Delete Greet :)");
	}

	// endpoint :: http://localhost:8181/myfirstapi/greetput
	@PutMapping("greetput")
	public ResponseEntity<String> putGreetings() {
		log.info("putGreetings()");
		return ResponseEntity.status(HttpStatus.OK).body("Testing PUT Greet :)");
	}

	// endpoint :: http://localhost:8181/myfirstapi/greetpost
	@PostMapping("greetpost")
	public ResponseEntity<String> newGreetings() {
		log.info("newGreetings()");
		return ResponseEntity.status(HttpStatus.OK).body("Testing Post Greet :)");
	}

	// endpoint :: http://localhost:8181/myfirstapi/greetget
	@GetMapping("greetget")
	public ResponseEntity<String> greetings() { // Method Returning Response
		log.info("greetings()");
		return ResponseEntity.status(HttpStatus.OK).body("Hello, Welcome to Spring Boot :)");
	}

}