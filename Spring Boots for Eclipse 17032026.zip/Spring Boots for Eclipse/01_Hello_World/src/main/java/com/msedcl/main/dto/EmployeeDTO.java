package com.msedcl.main.dto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;
@Data
public class EmployeeDTO {
	
	/*private Integer employeeId;
	private String firstName ;
	private String lastName;
	
	private double salary;
*/
	
	private Integer employeeId;
	
	@NotBlank(message = "First name cannot be blank")
	@Size(min = 2 , max = 50, message = "First name must be between 2 and 50 characters")
	private String firstName;
	
	@NotBlank(message = "Last name cannot be blank")
	@Size(min = 2 , max = 50, message = "Last name must be between 2 and 50 characters")
	private String lastName;
	
	@Positive(message = "Salary must be greater than 0")
	private double salary;

}
