package com.msedcl.main.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Entity
@Table(name="employee_details")
public class Employee {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	@Column(name = "employee_id")
	private Integer employeeId;
	@Column(name = "first_name", length = 50, nullable = false)
	private String firstName ;
	@Column(name = "last_name", length = 50, nullable = false)
	private String lastName;
	@Column(name = "salary", nullable = false)
	private double salary;

}
