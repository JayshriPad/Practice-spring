package com.msedcl.main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class BookDTO {

    private Integer bookCode;

    @NotBlank(message = "Title cannot be blank")
    @Size(max = 200, message = "Title cannot exceed 200 characters")
    private String title;

    @NotBlank(message = "Author cannot be blank")
    @Size(max = 100, message = "Author cannot exceed 100 characters")
    private String author;

    private boolean isReference;

    @NotBlank(message = "Availability status cannot be blank")
    private String availabilityStatus; // AVAILABLE / ISSUED
}