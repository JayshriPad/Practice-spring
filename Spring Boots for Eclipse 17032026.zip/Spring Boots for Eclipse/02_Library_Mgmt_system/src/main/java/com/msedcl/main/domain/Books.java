package com.msedcl.main.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Entity
@Table(name="books")
public class Books {
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "book_code")
	    private Integer bookCode;

	    @Column(name = "title", nullable = false, length = 200)
	    private String title;

	    @Column(name = "author", nullable = false, length = 100)
	    private String author;

	    @Column(name = "is_reference")
	    private boolean isReference = false;

	    @Column(name = "availability_status")
	    private String availabilityStatus = "AVAILABLE";

}
/*
 book_code INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100) NOT NULL,
    is_reference BOOLEAN DEFAULT FALSE, 
    availability_status ENUM('AVAILABLE', 'ISSUED') DEFAULT 'AVAILABLE'
*/