package com.msedcl.main.domain;

import java.awt.print.Book;
import java.lang.reflect.Member;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Entity
@Table(name="book_issues")
public class BookIssue {
	   @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "issue_id")
	    private Integer issueId;

	    @ManyToOne
	    @JoinColumn(name = "member_code")
	    private Member member;

	    @ManyToOne
	    @JoinColumn(name = "book_code")
	    private Book book;

	    @Column(name = "issue_date", nullable = false)
	    private LocalDate issueDate;

	    @Column(name = "due_date", nullable = false)
	    private LocalDate dueDate;

}
