package com.msedcl.main.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Entity
@Table(name="members")
public class Members extends BaseEntity { //extends BaseEntity added on dt 16-03-2026
	   @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "member_code")
	    private Integer memberCode;

	    @Column(name = "member_name", nullable = false, length = 100)
	    private String memberName;

	    @Column(name = "member_type", nullable = false, length = 20)
	    private String memberType; // STUDENT / FACULTY

	    @Column(name = "books_issued_count")
	    private Integer booksIssuedCount = 0;
}



