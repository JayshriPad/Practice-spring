package com.msedcl.main.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MemberResponseDTO {
	   private Integer memberCode;
	  
	    private String memberName;
	   
	    private String memberType; // STUDENT / FACULTY
	   
	    private Integer booksIssuedCount = 0;
	    
}
