package com.msedcl.main.member.audit;


import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

@Component("auditAwareImpl")
public class AuditAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		// get current loggedin user details
		return Optional.of("MEMBER-MS");
	}
	
	

}