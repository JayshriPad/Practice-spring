package com.msedcl.main.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.dto.MemberDTO;
import com.msedcl.main.dto.MemberResponseDTO;
import com.msedcl.main.dto.ResponseDTO;
import com.msedcl.main.member.common.ApiResponse;
import com.msedcl.main.service.MembersService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * MembersCRUDController
 *
 * This REST controller exposes CRUD operations for library members.
 */
@Validated
@RestController
@RequestMapping("memberscrudapi")
@AllArgsConstructor     // Lombok annotation for constructor injection
@Slf4j                  // Lombok annotation for logging
@Tag(
		name="Create REST API for CRUD operations of Library Member",
		description="Member create , Member by singleMember")
public class MembersCRUDController {

    private final MembersService membersService;

    /**
     * Delete a member by member code
     * Example: DELETE http://localhost:8181/memberscrudapi/members/member/101
     */
    /* commented on dt 16-03-2026  
     @DeleteMapping("members/member/{memberCode}")
    public ResponseEntity<ResponseDTO> removeMember(@PathVariable int memberCode) {
        log.info("Deleting member with code: {}", memberCode);

        boolean deleted = membersService.deleteMemberByMemberCode(memberCode);

        ResponseDTO responseDTO = new ResponseDTO(
                HttpStatus.OK,
                deleted ? "Member Deleted Successfully" : "Failed to Delete Member"
        );

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }*/
    
    @DeleteMapping("members/member/{memberCode}")
    @Operation(
            summary = "Delete Member REST API",
            description = "REST API to delete a member based on memberCode"
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "HTTP Status Not Found"
            )
    })
    public ResponseEntity<ApiResponse<Boolean>> removeMember(@PathVariable int memberCode) {

        log.info("Deleting member with code: {}", memberCode);

        boolean deleted = membersService.deleteMemberByMemberCode(memberCode);

        ApiResponse<Boolean> response = ApiResponse.<Boolean>builder()
                .status(deleted ? "SUCCESS" : "FAILED")
                .message(deleted ? "Member Deleted Successfully" : "Failed to Delete Member")
                .data(deleted)
                .build();

        return ResponseEntity.ok(response);
    }

    /**
     * Update member information
     * Example: PUT http://localhost:8181/memberscrudapi/members/member
     */
    @PutMapping("members/member")
    @Operation(//added starton dt 16-03-2026
            summary = "Update Member Details REST API",
            description = "REST API to fetch Members details "
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "HTTP Status Not Found",
                    content = @io.swagger.v3.oas.annotations.media.Content(
                            schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ProblemDetail.class)
                    )
            )
    } 
    )
    public ResponseEntity<ResponseDTO> updateMember(@Valid @RequestBody MemberDTO memberDTO) {
        log.info("Updating member: {}", memberDTO);

        MemberDTO updatedMember = membersService.updateMember(memberDTO);

        ResponseDTO responseDTO;

        if (updatedMember != null) {
            responseDTO = new ResponseDTO(HttpStatus.OK, "Member Updated Successfully");
            return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
        } else {
            responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Failed to Update Member");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
        }
    }

    /**
     * Add a new member
     * Example: POST http://localhost:8181/memberscrudapi/members/member
     */
    @PostMapping("members/member")
    public ResponseEntity<ResponseDTO> newMember(@Valid @RequestBody MemberDTO memberDTO) {
        log.info("Adding new member: {}", memberDTO);

        MemberDTO insertedMemberDTO = membersService.addNewMember(memberDTO);

        ResponseDTO responseDTO = new ResponseDTO(
                HttpStatus.OK,
                "Member added with memberCode :: " + insertedMemberDTO.getMemberCode()
        );

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Get a single member by member code
     * Example: GET http://localhost:8181/memberscrudapi/members/member/101
     */
	

    @GetMapping("members/member/{memberCode}")
	@Operation(//added starton dt 16-03-2026
            summary = "Fetch Members Details REST API",
            description = "REST API to fetch Members details based on a memberCode"
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "HTTP Status Not Found",
                    content = @io.swagger.v3.oas.annotations.media.Content(
                            schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ProblemDetail.class)
                    )
            )
    } 
    )
    public ResponseEntity<ApiResponse<MemberDTO>> singleMember(@PathVariable int memberCode) {

        log.info("Fetching member with code: {}", memberCode);

        MemberDTO memberDTO = membersService.getMemberByMemberCode(memberCode);

        ApiResponse<MemberDTO> response = ApiResponse.<MemberDTO>builder()
                .status("SUCCESS")
                .message("Member fetched successfully")
                .data(memberDTO)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }// end dt 16-03-2026 
    /* commented on dt 16-03-2026
    public ResponseEntity<MemberDTO> singleMember(@PathVariable int memberCode) {
        log.info("Fetching member with code: {}", memberCode);

        MemberDTO memberDTO = membersService.getMemberByMemberCode(memberCode);
        return ResponseEntity.status(HttpStatus.OK).body(memberDTO);
    }
*/
    /**
     * Get all members
     * Example: GET http://localhost:8181/memberscrudapi/members
     */
  /*  commented on dt 16-03-2026
   @GetMapping("members")
    public ResponseEntity<List<MemberDTO>> allMembers() {
        log.info("Fetching all members");

        List<MemberDTO> memberList = membersService.getAllMembers();
        return ResponseEntity.status(HttpStatus.OK).body(memberList);
    }*/
    
    @GetMapping("members")
    @Operation(
            summary = "Fetch All Members REST API",
            description = "REST API to fetch all members from Library"
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            )
    })
    public ResponseEntity<ApiResponse<List<MemberDTO>>> allMembers() {

        log.info("Fetching all members");

        List<MemberDTO> memberList = membersService.getAllMembers();

        ApiResponse<List<MemberDTO>> response = ApiResponse.<List<MemberDTO>>builder()
                .status("SUCCESS")
                .message("Members fetched successfully")
                .data(memberList)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
/*  following code given by sir on dt 16-03-2026
package com.msedcl.main.member.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.member.common.ApiResponse;
import com.msedcl.main.member.dto.MemberRequestDTO;
import com.msedcl.main.member.dto.MemberResponseDTO;
import com.msedcl.main.member.service.MemberService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@Validated
@RestController
@RequestMapping("membersapi")
@AllArgsConstructor
@Tag(name="Customer REST API for CRUD Operation",
description="Customer CREAT,Customer by CustomerID,Get All Customers")

public class MemberController {
	private final MemberService memberService;

	// Get member by memberId
	
    
	@GetMapping("members/member/{memberId}")
	public ResponseEntity<ApiResponse<MemberResponseDTO>> getMemberByMemberId(@PathVariable int memberId) {
		MemberResponseDTO customerResponseDTO = memberService.getMemberById(memberId);
		ApiResponse<MemberResponseDTO> response = ApiResponse.<MemberResponseDTO>builder()
				.status("SUCCESS")
				.message("Member Details Retrieved Successfully")
				.data(customerResponseDTO)
				.build();
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	// Create new customer
	
	
	@PostMapping("members/member")
	public ResponseEntity<ApiResponse<MemberResponseDTO>> createNewCustomer(
			@Valid @RequestBody MemberRequestDTO memberRequestDTO) {
		MemberResponseDTO customerResponseDTO = memberService.createMember(memberRequestDTO);
		ApiResponse<MemberResponseDTO> response = ApiResponse.<MemberResponseDTO>builder()
				.status("SUCCESS")
				.message("New Member Created Successfully")
				.data(customerResponseDTO)
				.build();
		return ResponseEntity.status(HttpStatus.CREATED).body(response);

	}
	
	@GetMapping("members")
	public ResponseEntity<ApiResponse<List<MemberResponseDTO>>> getAllCustomer() {
		List<MemberResponseDTO> customerResponseDTO = memberService.getAllMembers();
		
		
			ApiResponse<List<MemberResponseDTO>> response = ApiResponse.<List<MemberResponseDTO>>builder()
					.status("SUCCESS")
					.message("Member Details Retrieved Successfully")
					.data(customerResponseDTO)
					.build();
			return ResponseEntity.ok(response);
		}
	
	@PutMapping("members/member")
	public ResponseEntity<MemberResponseDTO> updateMember(@Valid @RequestBody MemberRequestDTO member) {
		//log.info(member.toString());
		MemberResponseDTO insertStatus = memberService.updateMember(member);
		if (insertStatus!=null) {
			MemberResponseDTO responseDTO = new MemberResponseDTO(insertStatus.getMemberId(),insertStatus.getMemberType(),insertStatus.getMemberName());
			return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
		} else {
			MemberResponseDTO responseDTO = new MemberResponseDTO(insertStatus.getMemberId(),insertStatus.getMemberType(),insertStatus.getMemberName());
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(responseDTO);
		}

	}
	

	
}
*/
 