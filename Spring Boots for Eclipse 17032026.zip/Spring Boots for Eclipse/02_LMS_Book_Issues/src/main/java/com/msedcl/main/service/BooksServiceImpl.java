package com.msedcl.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.msedcl.main.domain.Books;
import com.msedcl.main.dto.BooksDTO;
import com.msedcl.main.exception.BookNotFoundException;
import com.msedcl.main.mapper.BooksMapper;
import com.msedcl.main.repository.BooksRepository;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Service
@Slf4j
public class BooksServiceImpl implements BooksService {

    private final BooksRepository booksRepository;

    @Override
    public BooksDTO addNewBook(BooksDTO booksDTO) {

        Books book = BooksMapper.mapToBooks(booksDTO, new Books());

        Books insertedBook = booksRepository.save(book);

        Optional<Books> optionalBook =
                booksRepository.findById(insertedBook.getBookCode());

        if (optionalBook.isPresent()) {

            Books existingBook = optionalBook.get();

            BooksDTO addedBookDTO =
                    BooksMapper.mapToBooksDTO(existingBook, new BooksDTO());

            return addedBookDTO;
        }
        else
            return null;
    }

    @Override
    public boolean deleteBookByBookCode(int bookCode) {

        Optional<Books> optionalBook = booksRepository.findById(bookCode);

        if (optionalBook.isPresent()) {

            Books book = optionalBook.get();

            booksRepository.delete(book);

            return true;
        }
        else
            throw new BookNotFoundException("Invalid Book Code :: " + bookCode);
    }

    @Override
    public BooksDTO updateBook(BooksDTO booksDTO) {

        Books book = BooksMapper.mapToBooks(booksDTO, new Books());

        Optional<Books> optionalBook =
                booksRepository.findById(book.getBookCode());

        if (optionalBook.isPresent()) {

            Books updatedBook = booksRepository.save(book);

            BooksDTO updatedBookDTO =
                    BooksMapper.mapToBooksDTO(updatedBook, new BooksDTO());

            return updatedBookDTO;
        }
        else
            return null;
    }

    @Override
    public BooksDTO getBookByBookCode(int bookCode) {

        Optional<Books> optionalBook = booksRepository.findById(bookCode);

        if (optionalBook.isPresent()) {

            Books existingBook = optionalBook.get();

            BooksDTO booksDTO =
                    BooksMapper.mapToBooksDTO(existingBook, new BooksDTO());

            return booksDTO;
        }
        else
            throw new BookNotFoundException("Invalid Book Code :: " + bookCode);
    }

    @Override
    public List<BooksDTO> getAllBooks() {

        List<BooksDTO> booksDTOList = new ArrayList<>();

        for (Books book : booksRepository.findAll()) {

            BooksDTO booksDTO =
                    BooksMapper.mapToBooksDTO(book, new BooksDTO());

            booksDTOList.add(booksDTO);
        }

        return booksDTOList;
    }
}