
package com.msedcl.main.mapper;

import com.msedcl.main.domain.BookIssues;
import com.msedcl.main.dto.BookIssuesDTO;

public class BookIssuesMapper {

    // DTO -> Entity
    public static BookIssues mapToBookIssues(BookIssuesDTO dto, BookIssues entity) {

        entity.setIssueId(dto.getIssueId());
        entity.setMemberCode(dto.getMemberCode());
        entity.setBookCode(dto.getBookCode());
        entity.setIssueDate(dto.getIssueDate());
        entity.setDueDate(dto.getDueDate());

        return entity;
    }

    // Entity -> DTO
    public static BookIssuesDTO mapToBookIssuesDTO(BookIssues entity, BookIssuesDTO dto) {

        dto.setIssueId(entity.getIssueId());
        dto.setMemberCode(entity.getMemberCode());
        dto.setBookCode(entity.getBookCode());
        dto.setIssueDate(entity.getIssueDate());
        dto.setDueDate(entity.getDueDate());

        return dto;
    }
}