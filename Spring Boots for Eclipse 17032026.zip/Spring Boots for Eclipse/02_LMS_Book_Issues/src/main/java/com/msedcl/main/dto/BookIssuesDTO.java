package com.msedcl.main.dto;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class BookIssuesDTO {
	 
	  private Integer issueId;

	    @NotNull(message = "Member code is required")
	    private Integer memberCode;

	    @NotNull(message = "Book code is required")
	    private Integer bookCode;

	    @NotNull(message = "Issue date is required")
	    private LocalDate issueDate;

	    @NotNull(message = "Due date is required")
	    @FutureOrPresent(message = "Due date cannot be in the past")
	    private LocalDate dueDate;

}
