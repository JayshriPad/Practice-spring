package com.msedcl.main.mapper;



import com.msedcl.main.domain.Books;
import com.msedcl.main.dto.BooksDTO;

public class BooksMapper {   // No annotation needed

    // DTO -> Entity
    public static Books mapToBooks(BooksDTO booksDTO, Books books) {

        books.setBookCode(booksDTO.getBookCode());
        books.setTitle(booksDTO.getTitle());
        books.setAuthor(booksDTO.getAuthor());
        books.setReference(booksDTO.isReference());
        books.setAvailabilityStatus(booksDTO.getAvailabilityStatus());

        return books;
    }

    // Entity -> DTO
    public static BooksDTO mapToBooksDTO(Books books, BooksDTO booksDTO) {

        booksDTO.setBookCode(books.getBookCode());
        booksDTO.setTitle(books.getTitle());
        booksDTO.setAuthor(books.getAuthor());
        booksDTO.setReference(books.isReference());
        booksDTO.setAvailabilityStatus(books.getAvailabilityStatus());

        return booksDTO;
    }
}