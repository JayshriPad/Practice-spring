package com.msedcl.main.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.msedcl.main.domain.BookIssues;
import com.msedcl.main.domain.Books;


@Repository
public interface BookIssuesRepository extends JpaRepository<Books, Integer> {
	 // Find all issues for a specific member
 //   List<BookIssues> findByMemberCode(Integer memberCode);

    // Find an issue by book code (to check if a book is already issued)
   // Optional<BookIssues> findByBookCode(Integer bookCode);

    // Count how many books a member has issued (useful for member limit)
    //int countByMemberCode(Integer memberCode);

}