package com.msedcl.main.service;

import java.util.List;

import com.msedcl.main.dto.BooksDTO;

public interface BooksService {

    BooksDTO addNewBook(BooksDTO booksDTO);

    boolean deleteBookByBookCode(int bookCode);

    BooksDTO updateBook(BooksDTO booksDTO);

    BooksDTO getBookByBookCode(int bookCode);

    List<BooksDTO> getAllBooks();
}