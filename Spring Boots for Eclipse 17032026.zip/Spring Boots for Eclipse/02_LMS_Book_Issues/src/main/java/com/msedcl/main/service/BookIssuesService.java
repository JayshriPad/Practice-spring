package com.msedcl.main.service;

import java.util.List;

import com.msedcl.main.dto.BookIssuesDTO;

public interface BookIssuesService {

 
}