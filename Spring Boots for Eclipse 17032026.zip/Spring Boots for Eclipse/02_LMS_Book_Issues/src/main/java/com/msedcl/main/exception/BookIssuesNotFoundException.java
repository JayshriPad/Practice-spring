package com.msedcl.main.exception;

public class BookIssuesNotFoundException extends RuntimeException {

    public BookIssuesNotFoundException(String message) {
        super(message);
    }
}
