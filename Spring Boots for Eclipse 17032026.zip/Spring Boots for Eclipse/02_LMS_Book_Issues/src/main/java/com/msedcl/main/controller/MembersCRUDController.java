package com.msedcl.main.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.dto.MemberDTO;
import com.msedcl.main.dto.ResponseDTO;
import com.msedcl.main.service.MembersService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * MembersCRUDController
 *
 * This REST controller exposes CRUD operations for library members.
 */
@Validated
@RestController
@RequestMapping("memberscrudapi")
@AllArgsConstructor     // Lombok annotation for constructor injection
@Slf4j                  // Lombok annotation for logging
public class MembersCRUDController {

    private final MembersService membersService;

    /**
     * Delete a member by member code
     * Example: DELETE http://localhost:8181/memberscrudapi/members/member/101
     */
    @DeleteMapping("members/member/{memberCode}")
    public ResponseEntity<ResponseDTO> removeMember(@PathVariable int memberCode) {
        log.info("Deleting member with code: {}", memberCode);

        boolean deleted = membersService.deleteMemberByMemberCode(memberCode);

        ResponseDTO responseDTO = new ResponseDTO(
                HttpStatus.OK,
                deleted ? "Member Deleted Successfully" : "Failed to Delete Member"
        );

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Update member information
     * Example: PUT http://localhost:8181/memberscrudapi/members/member
     */
    @PutMapping("members/member")
    public ResponseEntity<ResponseDTO> updateMember(@Valid @RequestBody MemberDTO memberDTO) {
        log.info("Updating member: {}", memberDTO);

        MemberDTO updatedMember = membersService.updateMember(memberDTO);

        ResponseDTO responseDTO;

        if (updatedMember != null) {
            responseDTO = new ResponseDTO(HttpStatus.OK, "Member Updated Successfully");
            return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
        } else {
            responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Failed to Update Member");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
        }
    }

    /**
     * Add a new member
     * Example: POST http://localhost:8181/memberscrudapi/members/member
     */
    @PostMapping("members/member")
    public ResponseEntity<ResponseDTO> newMember(@Valid @RequestBody MemberDTO memberDTO) {
        log.info("Adding new member: {}", memberDTO);

        MemberDTO insertedMemberDTO = membersService.addNewMember(memberDTO);

        ResponseDTO responseDTO = new ResponseDTO(
                HttpStatus.OK,
                "Member added with memberCode :: " + insertedMemberDTO.getMemberCode()
        );

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Get a single member by member code
     * Example: GET http://localhost:8181/memberscrudapi/members/member/101
     */
    @GetMapping("members/member/{memberCode}")
    public ResponseEntity<MemberDTO> singleMember(@PathVariable int memberCode) {
        log.info("Fetching member with code: {}", memberCode);

        MemberDTO memberDTO = membersService.getMemberByMemberCode(memberCode);
        return ResponseEntity.status(HttpStatus.OK).body(memberDTO);
    }

    /**
     * Get all members
     * Example: GET http://localhost:8181/memberscrudapi/members
     */
    @GetMapping("members")
    public ResponseEntity<List<MemberDTO>> allMembers() {
        log.info("Fetching all members");

        List<MemberDTO> memberList = membersService.getAllMembers();
        return ResponseEntity.status(HttpStatus.OK).body(memberList);
    }
}