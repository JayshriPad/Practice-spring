
package com.msedcl.main.service;

import java.util.List;

import com.msedcl.main.dto.MemberDTO;

public interface MembersService {

    MemberDTO addNewMember(MemberDTO memberDTO);

    boolean deleteMemberByMemberCode(int memberCode);

    MemberDTO updateMember(MemberDTO memberDTO);

    MemberDTO getMemberByMemberCode(int memberCode);

    List<MemberDTO> getAllMembers();
}