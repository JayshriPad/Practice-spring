package com.msedcl.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.msedcl.main.domain.Books;


@Repository
public interface BooksRepository extends JpaRepository<Books, Integer> {
   
}