package com.msedcl.main.bookissues.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.msedcl.main.bookissues.common.ApiResponse;
import com.msedcl.main.dto.BookIssuesDTO;
import com.msedcl.main.dto.BooksDTO;
import com.msedcl.main.exception.BookNotFoundException;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class BookIssuesServiceClient {
	private final RestTemplate restTemplate;
	
	public BooksDTO getIssueByBookCode(Integer bookCode) {
		String url = "http://localhost:8186/bookscrudapi/books/book/" + bookCode;
		
		try {			ResponseEntity<ApiResponse<BooksDTO>> response = restTemplate.exchange(url, HttpMethod.GET, null,
				new ParameterizedTypeReference<ApiResponse<BooksDTO>>() {
				});

		  if (response.getBody() == null || response.getBody().getData() == null) {
              throw new BookNotFoundException("Book not found :: " + bookCode);
          }
		
		return response.getBody().getData();
	} catch (HttpClientErrorException.NotFound e) {
		throw new BookNotFoundException("Invalid bookCode :: " + bookCode);
	}
		
	
}
	
	
}
/*package com.msedcl.main.bookissues.client;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.msedcl.main.bookissues.common.ApiResponse;
import com.msedcl.main.bookissues.dto.BooksDTO;
import com.msedcl.main.bookissues.exception.BookNotFoundException;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class BookIssuesServiceClient {

    private final RestTemplate restTemplate;

    public BooksDTO getBookByCode(Integer bookCode) {
        String url = "http://localhost:8186/bookscrudapi/books/book/" + bookCode;

        try {
            ResponseEntity<ApiResponse<BooksDTO>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ApiResponse<BooksDTO>>() {}
            );

            if (response.getBody() == null || response.getBody().getData() == null) {
                throw new BookNotFoundException("Book not found :: " + bookCode);
            }

            return response.getBody().getData();

        } catch (HttpClientErrorException.NotFound e) {
            throw new BookNotFoundException("Invalid bookCode :: " + bookCode);
        }
    }
}*/