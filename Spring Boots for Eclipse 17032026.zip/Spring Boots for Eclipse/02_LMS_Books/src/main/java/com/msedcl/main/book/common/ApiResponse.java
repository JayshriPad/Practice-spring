package com.msedcl.main.book.common;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiResponse<T> {  //<T> any type in this case Member response DTO

	private String status;
	private String message;
	private T data;
	
}
