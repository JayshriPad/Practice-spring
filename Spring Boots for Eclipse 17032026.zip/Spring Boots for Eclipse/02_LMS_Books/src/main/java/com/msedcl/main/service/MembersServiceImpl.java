package com.msedcl.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.msedcl.main.domain.Members;
import com.msedcl.main.dto.MemberDTO;
import com.msedcl.main.exception.MemberNotFoundException;
import com.msedcl.main.mapper.MemberMapper;
import com.msedcl.main.repository.MembersRepository;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Service
@Slf4j
public class MembersServiceImpl implements MembersService {

    private final MembersRepository membersRepository;

    @Override
    public MemberDTO addNewMember(MemberDTO memberDTO) {

        Members member = MemberMapper.mapToMember(memberDTO, new Members());

        Members insertedMember = membersRepository.save(member);

        Optional<Members> optionalMember =
                membersRepository.findById(insertedMember.getMemberCode());

        if (optionalMember.isPresent()) {

            Members existingMember = optionalMember.get();

            MemberDTO addedMemberDTO =
                    MemberMapper.mapToMemberDTO(existingMember, new MemberDTO());

            return addedMemberDTO;
        } 
        else
            return null;
    }

    @Override
    public boolean deleteMemberByMemberCode(int memberCode) {

        Optional<Members> optionalMember = membersRepository.findById(memberCode);

        if (optionalMember.isPresent()) {

            Members member = optionalMember.get();

            membersRepository.delete(member);

            return true;
        } 
        else
            throw new MemberNotFoundException("Invalid Member Code :: " + memberCode);
    }

    @Override
    public MemberDTO updateMember(MemberDTO memberDTO) {

        Members member = MemberMapper.mapToMember(memberDTO, new Members());

        Optional<Members> optionalMember =
                membersRepository.findById(member.getMemberCode());

        if (optionalMember.isPresent()) {

            Members updatedMember = membersRepository.save(member);

            MemberDTO updatedMemberDTO =
                    MemberMapper.mapToMemberDTO(updatedMember, new MemberDTO());

            return updatedMemberDTO;
        } 
        else
            return null;
    }

    @Override
    public MemberDTO getMemberByMemberCode(int memberCode) {

        Optional<Members> optionalMember = membersRepository.findById(memberCode);

        if (optionalMember.isPresent()) {

            Members existingMember = optionalMember.get();

            MemberDTO memberDTO =
                    MemberMapper.mapToMemberDTO(existingMember, new MemberDTO());

            return memberDTO;
        } 
        else
            throw new MemberNotFoundException("Invalid Member Code :: " + memberCode);
    }

    @Override
    public List<MemberDTO> getAllMembers() {

        List<MemberDTO> memberDTOList = new ArrayList<>();

        for (Members member : membersRepository.findAll()) {

            MemberDTO memberDTO =
                    MemberMapper.mapToMemberDTO(member, new MemberDTO());

            memberDTOList.add(memberDTO);
        }

        return memberDTOList;
    }
}