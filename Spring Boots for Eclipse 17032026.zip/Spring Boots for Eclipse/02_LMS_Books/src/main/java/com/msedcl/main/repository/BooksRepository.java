package com.msedcl.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.msedcl.main.domain.Books;

/**
 * Repository interface for Books entity
 * Provides CRUD operations without needing explicit implementation
 */
@Repository
public interface BooksRepository extends JpaRepository<Books, Integer> {
    // You can add custom queries here if needed, e.g.:
    // List<Books> findByAvailabilityStatus(String status);
}