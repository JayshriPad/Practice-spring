package com.msedcl.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.msedcl.main.domain.Members;

@Repository
public interface MembersRepository extends JpaRepository<Members, Integer> {

}