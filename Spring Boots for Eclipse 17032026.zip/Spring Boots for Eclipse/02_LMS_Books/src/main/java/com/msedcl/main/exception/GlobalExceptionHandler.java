package com.msedcl.main.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.msedcl.main.dto.ErrorResponseDTO;
/*postman
 POST    http://localhost:8181/employeecrudapi/employees/employee
 {
   
    "firstName": "",
    "lastName": "",
    "salary": -10
}

--->
{
    "firstName": "First name cannot be blank",
    "lastName": "Last name must be between 2 and 50 characters",
    "salary": "Salary must be greater than 0"
}
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected @Nullable ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		
		Map<String, String> validationErrors = new HashMap<>();

		//Load all errors
		List<ObjectError> errors = ex.getBindingResult().getAllErrors();

		//adding field name and error message into map
		for (ObjectError objectError : errors) {
			String field = ((FieldError) objectError).getField(); // key
			String message = objectError.getDefaultMessage(); // value
			validationErrors.put(field, message);
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationErrors);
	}
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<ProblemDetail> handleEmployeeNotFoundException(
			EmployeeNotFoundException employeeNotFoundException) {
		ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
		problemDetail.setDetail(employeeNotFoundException.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(problemDetail);
	}
	
	/*@ExceptionHandler(MemberNotFoundException.class)//http://localhost:8181/swagger-ui/index.html#/Create%20REST%20API%20for%20CRUD%20operations/getCustomerByCustomerId
	public ResponseEntity<ErrorResponseDTO> handleMemberNotFoundException(
			MemberNotFoundException customerNotFoundException, WebRequest request) {
//		ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
//		problemDetail.setDetail(customerNotFoundException.getMessage());
		ErrorResponseDTO errorResponseDTO = new ErrorResponseDTO();
		errorResponseDTO.setApiPath(request.getDescription(false));
		errorResponseDTO.setErrorMessage("Invalid memberCode. ");
		errorResponseDTO.setStatus(HttpStatus.NOT_FOUND);
		errorResponseDTO.setErrorTime(LocalDateTime.now());

		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponseDTO);
	}*/
	
	@ExceptionHandler(MemberNotFoundException.class)//http://localhost:8181/swagger-ui/index.html#/Create%20REST%20API%20for%20CRUD%20operations/getCustomerByCustomerId
	public ResponseEntity<ErrorResponseDTO> handleBookNotFoundException(
			MemberNotFoundException customerNotFoundException, WebRequest request) {
//		ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
//		problemDetail.setDetail(customerNotFoundException.getMessage());
		ErrorResponseDTO errorResponseDTO = new ErrorResponseDTO();
		errorResponseDTO.setApiPath(request.getDescription(false));
		errorResponseDTO.setErrorMessage("Invalid bookCode. ");
		errorResponseDTO.setStatus(HttpStatus.NOT_FOUND);
		errorResponseDTO.setErrorTime(LocalDateTime.now());

		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponseDTO);
	}
	
}

/*package com.msedcl.main.exceptions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected @Nullable ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		
		Map<String, String> validationErrors = new HashMap<>();

		//Load all errors
		List<ObjectError> errors = ex.getBindingResult().getAllErrors();

		//adding field name and error message into map
		for (ObjectError objectError : errors) {
			String field = ((FieldError) objectError).getField(); // key
			String message = objectError.getDefaultMessage(); // value
			validationErrors.put(field, message);
		}

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationErrors);
	}

	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<ProblemDetail> handleEmployeeNotFoundException(
			EmployeeNotFoundException employeeNotFoundException) {
		ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
		problemDetail.setDetail(employeeNotFoundException.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(problemDetail);
	}
}
*/