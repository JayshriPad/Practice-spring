package com.msedcl.main.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.msedcl.main.book.common.ApiResponse;
import com.msedcl.main.dto.BooksDTO;
import com.msedcl.main.dto.ResponseDTO;
import com.msedcl.main.service.BooksService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Validated
@RestController
@RequestMapping("bookscrudapi")
@AllArgsConstructor
@Slf4j
@Tag(
        name = "Create REST API for CRUD operations of Library Books",
        description = "Book insert , Book fetch, update and delete APIs"
)
public class BooksCRUDController {

    private final BooksService booksService;

    /**
     * Delete Book
     * Example:
     * DELETE http://localhost:8182/bookscrudapi/books/book/101
     */
    @DeleteMapping("books/book/{bookCode}")
    @Operation(
            summary = "Delete Book REST API",
            description = "REST API to delete a book based on bookCode"
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "HTTP Status Not Found"
            )
    })
    public ResponseEntity<ApiResponse<Boolean>> removeBook(@PathVariable int bookCode) {

        log.info("Deleting book with code: {}", bookCode);

        boolean deleted = booksService.deleteBookByBookCode(bookCode);

        ApiResponse<Boolean> response = ApiResponse.<Boolean>builder()
                .status(deleted ? "SUCCESS" : "FAILED")
                .message(deleted ? "Book Deleted Successfully" : "Failed to Delete Book")
                .data(deleted)
                .build();

        return ResponseEntity.ok(response);
    }

    /**
     * Update Book
     * Example:
     * PUT http://localhost:8182/bookscrudapi/books/book
     */
    @PutMapping("books/book")
    @Operation(
            summary = "Update Book Details REST API",
            description = "REST API to update book details"
    )
    public ResponseEntity<ResponseDTO> updateBook(@Valid @RequestBody BooksDTO booksDTO) {

        log.info("Updating book: {}", booksDTO);

        BooksDTO updatedBook = booksService.updateBook(booksDTO);

        ResponseDTO responseDTO;

        if (updatedBook != null) {
            responseDTO = new ResponseDTO(HttpStatus.OK, "Book Updated Successfully");
            return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
        } else {
            responseDTO = new ResponseDTO(HttpStatus.BAD_REQUEST, "Failed to Update Book");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
        }
    }

    /**
     * Add New Book
     * Example:
     * POST http://localhost:8182/bookscrudapi/books/book
     */
    @PostMapping("books/book")
    @Operation(
            summary = "Create Book REST API",
            description = "REST API to create new book in Library"
    )
    public ResponseEntity<ResponseDTO> newBook(@Valid @RequestBody BooksDTO booksDTO) {

        log.info("Adding new book: {}", booksDTO);

        BooksDTO insertedBookDTO = booksService.addNewBook(booksDTO);

        ResponseDTO responseDTO = new ResponseDTO(
                HttpStatus.OK,
                "Book added with bookCode :: " + insertedBookDTO.getBookCode()
        );

        return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
    }

    /**
     * Get Book By Code
     * Example:
     * GET http://localhost:8182/bookscrudapi/books/book/101
     */
    @GetMapping("books/book/{bookCode}")
    @Operation(
            summary = "Fetch Book Details REST API",
            description = "REST API to fetch book details based on bookCode"
    )
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "HTTP Status OK"
            ),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "404",
                    description = "HTTP Status Not Found",
                    content = @io.swagger.v3.oas.annotations.media.Content(
                            schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ProblemDetail.class)
                    )
            )
    })
    public ResponseEntity<ApiResponse<BooksDTO>> singleBook(@PathVariable int bookCode) {

        log.info("Fetching book with code: {}", bookCode);

        BooksDTO booksDTO = booksService.getBookByBookCode(bookCode);

        ApiResponse<BooksDTO> response = ApiResponse.<BooksDTO>builder()
                .status("SUCCESS")
                .message("Book fetched successfully")
                .data(booksDTO)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    /**
     * Get All Books
     * Example:
     * GET http://localhost:8182/bookscrudapi/books
     */
    @GetMapping("books")
    @Operation(
            summary = "Fetch All Books REST API",
            description = "REST API to fetch all books from Library"
    )
    public ResponseEntity<ApiResponse<List<BooksDTO>>> allBooks() {

        log.info("Fetching all books");

        List<BooksDTO> bookList = booksService.getAllBooks();

        ApiResponse<List<BooksDTO>> response = ApiResponse.<List<BooksDTO>>builder()
                .status("SUCCESS")
                .message("Books fetched successfully")
                .data(bookList)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}