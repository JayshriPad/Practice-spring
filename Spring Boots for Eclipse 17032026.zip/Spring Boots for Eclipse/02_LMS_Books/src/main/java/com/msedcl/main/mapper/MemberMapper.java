package com.msedcl.main.mapper;

import com.msedcl.main.domain.Members;
import com.msedcl.main.dto.MemberDTO;

public class MemberMapper {   // no need to add annotation

    // DTO -> Entity
    public static Members mapToMember(MemberDTO memberDTO, Members member) {

        member.setMemberCode(memberDTO.getMemberCode());
        member.setMemberName(memberDTO.getMemberName());
        member.setMemberType(memberDTO.getMemberType());
        member.setBooksIssuedCount(memberDTO.getBooksIssuedCount());

        return member;
    }

    // Entity -> DTO
    public static MemberDTO mapToMemberDTO(Members member, MemberDTO memberDTO) {

        memberDTO.setMemberCode(member.getMemberCode());
        memberDTO.setMemberName(member.getMemberName());
        memberDTO.setMemberType(member.getMemberType());
        memberDTO.setBooksIssuedCount(member.getBooksIssuedCount());

        return memberDTO;
    }
}