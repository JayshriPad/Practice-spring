package com.msedcl.main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

public class MemberResponseDTO {
	 private Integer memberCode;

	    @NotBlank(message = "Member name cannot be blank")
	    @Size(min = 2, max = 100, message = "Member name must be between 2 and 100 characters")
	    private String memberName;

	    @NotBlank(message = "Member type cannot be blank")
	    private String memberType;   // STUDENT / FACULTY

	    @PositiveOrZero(message = "Books issued count cannot be negative")
	    private Integer booksIssuedCount;
}