package com.msedcl.main.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookIssueRequestDTO {
    private Integer memberCode;
    private Integer bookCode;
    
}