package com.msedcl.main.bookissues.client;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.msedcl.main.bookissues.common.ApiResponse;
import com.msedcl.main.dto.MemberResponseDTO;
import com.msedcl.main.exception.MemberNotFoundException;
//import com.msedcl.main.exception.MemberServiceException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MemberServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String MEMBER_SERVICE_BASE_URL =
            "http://localhost:8081/members";

    /**
     * Get Member Details
     */
    public MemberResponseDTO getMember(String memberCode) {

        String url = MEMBER_SERVICE_BASE_URL + "/" + memberCode;

        try {
            ResponseEntity<ApiResponse<MemberResponseDTO>> response =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            null,
                            new ParameterizedTypeReference<ApiResponse<MemberResponseDTO>>() {}
                    );

            return response.getBody().getData();

        } catch (HttpClientErrorException.NotFound e) {
            log.error("Member not found: {}", memberCode);
            throw new MemberNotFoundException("Invalid Member Code :: " + memberCode);
        }
      /*   catch (HttpServerErrorException.InternalServerError e) {
            log.error("Member service internal error: {}", e.getMessage());
            throw new MemberServiceException("Member Service unavailable");
        }*/
    }

    /**
     * Increment Issued Books Count
     */
    public void incrementBooks(String memberCode) {

        String url = MEMBER_SERVICE_BASE_URL + "/" + memberCode + "/increment-books";

        try {
            restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    null,
                    new ParameterizedTypeReference<ApiResponse<Void>>() {}
            );

        } catch (HttpClientErrorException.NotFound e) {
            log.error("Member not found while updating: {}", memberCode);
            throw new MemberNotFoundException("Invalid Member Code :: " + memberCode);

        } /*catch (HttpServerErrorException.InternalServerError e) {
            log.error("Member service error: {}", e.getMessage());
            throw new MemberServiceException("Member Service unavailable");
        }*/
    }
}