package com.msedcl.main.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookIssueResponseDTO {
    private Integer issueId;
    private Integer memberCode;
    private Integer bookCode;
    private LocalDate issueDate;
    private LocalDate dueDate;
    
}