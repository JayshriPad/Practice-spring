package com.msedcl.main.mapper;

import com.msedcl.main.domain.BookIssues;
import com.msedcl.main.dto.BookIssueRequestDTO;
import com.msedcl.main.dto.BookIssueResponseDTO;

public class BookIssuesMapper {

    // RequestDTO -> Entity
    public static BookIssues mapToEntity(BookIssueRequestDTO dto) {
        BookIssues entity = new BookIssues();
        entity.setMemberCode(dto.getMemberCode());
        entity.setBookCode(dto.getBookCode());
       // entity.setIssueDate(dto.getIssueDate());
        //entity.setDueDate(dto.getDueDate());
        return entity;
    }

    // Entity -> ResponseDTO
    public static BookIssueResponseDTO mapToResponseDTO(BookIssues entity, String message) {
        BookIssueResponseDTO dto = new BookIssueResponseDTO();
        dto.setIssueId(entity.getIssueId());
        dto.setMemberCode(entity.getMemberCode());
        dto.setBookCode(entity.getBookCode());
        dto.setIssueDate(entity.getIssueDate());
        dto.setDueDate(entity.getDueDate());
       
        return dto;
    }
}