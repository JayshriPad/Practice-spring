package com.msedcl.main.bookissues.client;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.msedcl.main.bookissues.common.ApiResponse;
import com.msedcl.main.dto.BookResponseDTO;
import com.msedcl.main.exception.BookNotFoundException;
//import com.msedcl.main.exception.BookServiceException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BookServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private static final String BOOK_SERVICE_BASE_URL =
            "http://localhost:8082/books";

    /**
     * Get Book Details
     */
    public BookResponseDTO getBook(String bookCode) {

        String url = BOOK_SERVICE_BASE_URL + "/" + bookCode;

        try {
            ResponseEntity<ApiResponse<BookResponseDTO>> response =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            null,
                            new ParameterizedTypeReference<ApiResponse<BookResponseDTO>>() {}
                    );

            return response.getBody().getData();

        } catch (HttpClientErrorException.NotFound e) {
            log.error("Book not found: {}", bookCode);
            throw new BookNotFoundException("Invalid Book Code :: " + bookCode);
        }
      /*   catch (HttpServerErrorException.InternalServerError e) {
            log.error("Book service internal error: {}", e.getMessage());
            throw new BookServiceException("Book Service unavailable");
        }*/
    }

    /**
     * Mark Book as Issued
     */
    public void markAsIssued(String bookCode) {

        String url = BOOK_SERVICE_BASE_URL + "/" + bookCode + "/mark-issued";

        try {
            restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    null,
                    new ParameterizedTypeReference<ApiResponse<Void>>() {}
            );

        } catch (HttpClientErrorException.NotFound e) {
            log.error("Book not found while updating: {}", bookCode);
            throw new BookNotFoundException("Invalid Book Code :: " + bookCode);

        }/* catch (HttpServerErrorException.InternalServerError e) {
            log.error("Book service error: {}", e.getMessage());
            throw new BookServiceException("Book Service unavailable");
        }*/
    }
}