package com.msedcl.main.service;

import org.springframework.stereotype.Service;

import com.msedcl.main.bookissues.client.BookIssuesServiceClient;
import com.msedcl.main.domain.BookIssues;
import com.msedcl.main.dto.BookIssueRequestDTO;
import com.msedcl.main.dto.BookIssueResponseDTO;
import com.msedcl.main.exception.BookNotFoundException;
import com.msedcl.main.repository.BookIssuesRepository;
import com.msedcl.main.service.BookIssuesService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BookIssuesServiceImpl implements BookIssuesService {

    private final BookIssuesRepository bookIssuesRepository;
    private final BookIssuesServiceClient bookIssuesServiceClient;

    @Override
    public BookIssueResponseDTO createBookIssue(BookIssueRequestDTO requestDTO) {

        // 1. Validate bookCode via external microservice
        bookIssuesServiceClient.getIssueByBookCode(requestDTO.getBookCode());

        // Optional: Add member validation here if needed

        // 2. Map DTO → Entity
        BookIssues bookIssue = new BookIssues();
        bookIssue.setBookCode(requestDTO.getBookCode());
        bookIssue.setMemberCode(requestDTO.getMemberCode());
      //  bookIssue.setIssueDate(requestDTO.getIssueDate());
    //  bookIssue.setDueDate(requestDTO.getDueDate());

        // 3. Save entity
        BookIssues savedIssue = bookIssuesRepository.save(bookIssue);

        // 4. Map Entity → ResponseDTO
        BookIssueResponseDTO responseDTO = new BookIssueResponseDTO();
        responseDTO.setIssueId(savedIssue.getIssueId());
        responseDTO.setBookCode(savedIssue.getBookCode());
        responseDTO.setMemberCode(savedIssue.getMemberCode());
        responseDTO.setIssueDate(savedIssue.getIssueDate());
        responseDTO.setDueDate(savedIssue.getDueDate());
      //  responseDTO.setResponseMessage("Book issue created successfully");

        return responseDTO;
    }

 /*   @Override
    public BookIssueResponseDTO getBookIssueById(Integer issueId) {
        BookIssues bookIssue = bookIssuesRepository.findById(issueId)
                .orElseThrow(() -> new BookNotFoundException("Book issue not found :: " + issueId));

        BookIssueResponseDTO responseDTO = new BookIssueResponseDTO();
        responseDTO.setIssueId(bookIssue.getIssueId());
        responseDTO.setBookCode(bookIssue.getBookCode());
        responseDTO.setMemberCode(bookIssue.getMemberCode());
        responseDTO.setIssueDate(bookIssue.getIssueDate());
        responseDTO.setDueDate(bookIssue.getDueDate());
        responseDTO.setResponseMessage("Book issue fetched successfully");

        return responseDTO;
    }*/
}