package com.msedcl.main.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Data Transfer Object for Books entity
 */
@Data
public class BookResponseDTO {

    private Integer bookCode;

    @NotBlank(message = "Title cannot be blank")
    @Size(min = 2, max = 200, message = "Title must be between 2 and 200 characters")
    private String title;

    @NotBlank(message = "Author cannot be blank")
    @Size(min = 2, max = 100, message = "Author name must be between 2 and 100 characters")
    private String author;

    // Whether the book is a reference book (cannot be issued)
    private boolean isReference = false;

    // Book availability status (AVAILABLE or ISSUED)
    private String availabilityStatus = "AVAILABLE";
}