
package com.msedcl.main.service;

import com.msedcl.main.dto.BookIssueRequestDTO;
import com.msedcl.main.dto.BookIssueResponseDTO;

public interface BookIssuesService {

    /**
     * Create a new Book Issue after validating book and member
     */
    BookIssueResponseDTO createBookIssue(BookIssueRequestDTO requestDTO);

    /**
     * Get a Book Issue by its issueId
     */
    BookIssueResponseDTO getBookIssueById(Integer issueId);
}