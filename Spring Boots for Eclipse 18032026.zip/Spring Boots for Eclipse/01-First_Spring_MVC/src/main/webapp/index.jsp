<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Simple JSP Form</title>
</head>
<body>

<h2>Send Data to Controller</h2>

<form action="MyController" method="post">
    Name: <input type="text" name="username" /><br><br>
    
    <input type="submit" value="Submit" />
</form>

</body>
</html>